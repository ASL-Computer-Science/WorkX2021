import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Task {
  private static TreeMap<String, String[]> flights = new TreeMap<>();

  public static ArrayList<String> allFlights(String filePath) throws FileNotFoundException {
    File flightsList = new File(filePath);
    Scanner scr = new Scanner(flightsList);
    while (scr.hasNextLine()) {
      String s = scr.nextLine();
      String flightN = s.substring(0, 5);
      s = s.substring(6).toLowerCase();
      String[] passengers = s.split(" ");
      flights.put(flightN, passengers);
    }
    TreeMap<Integer, String> flightsInOrder = new TreeMap<>();
    for(String k: flights.keySet()){
      int s = (flights.get(k).length);
      flightsInOrder.put(s,k);
    }
    ArrayList<String> finalFlightsInOrder = new ArrayList<>();
    for(int i: flightsInOrder.keySet()){
      finalFlightsInOrder.add(flightsInOrder.get(i));
    }
    return finalFlightsInOrder;
  }

  public static ArrayList<String> getPassengers(String filePath, String fn) throws FileNotFoundException {
    File flightsList = new File(filePath);
    Scanner scr = new Scanner(flightsList);
    while (scr.hasNextLine()) {
      String s = scr.nextLine();
      String flightN = s.substring(0, 5);
      s = s.substring(6).toLowerCase();
      String[] passengers = s.split(" ");
      flights.put(flightN, passengers);
    }
    TreeMap<String, Integer> passAlphabet = new TreeMap<>();
    String[] passengers = flights.get(fn);
    for(String name: passengers){
      passAlphabet.put(name, 1);
    }
    ArrayList<String> passengers1 = new ArrayList<>();
    for(String k: passAlphabet.keySet()){
      passengers1.add(k);
    }
    return passengers1;
  }
}


