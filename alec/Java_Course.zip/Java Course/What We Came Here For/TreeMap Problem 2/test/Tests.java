import org.junit.Assert;

import java.util.ArrayList;
import java.util.Arrays;

public class Tests {
  public void testAllFlights() {
    String msg = "All of the flight numbers should be in an alphabetized ArrayList";
    ArrayList<String> expec = new ArrayList<>();
    String [] s = {"DL432", "ET838", "UN473", "AA132", "JB239", "BA492", "QA922", "QU348", "AM695", "TS526"};
    expec.addAll(Arrays.asList(s));
    try {
      Assert.assertEquals(msg, expec, Task.allFlights("/Users/aleca/IdeaProjects/Java Course/What We Came Here For/TreeMap Problem 2/test/flights.txt"));
    }
    catch(Exception e){
      System.out.println("Something went wrong please try again.");
    }
  }

  public void testPassengers() {
    String msg = "The passengers should be in an alphabetized ArrayList ";
    ArrayList<String> expec = new ArrayList<>();
    String [] s = {"Connixiwa", "Erica", "Hello", "Hi", "Jody", "John", "Lizzie", "Nahhetweakin"};
    expec.addAll(Arrays.asList(s));
    try {
      Assert.assertEquals(msg, expec, Task.getPassengers("/Users/aleca/IdeaProjects/Java Course/What We Came Here For/TreeMap Problem 2/test/flights.txt", "QU348"));
    }
    catch(Exception e){
      System.out.println("Something went wrong please try again.");
    }
  }
}