import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.TreeMap;

public class Main {
   public static void main(String[] args) throws FileNotFoundException {
      File text = new File("/Users/aleca/IdeaProjects/Java Course/What We Came Here For/TreeMap Problem 1/src/input.txt");
      TreeMap<String, Integer> wordUsage = new TreeMap<>();
      Scanner scr = new Scanner(text);
      while(scr.hasNext()){
         String s = scr.next().toLowerCase();
         if((s.substring(s.length()-1).equals("."))||(s.substring(s.length()-1).equals(","))){
            s = s.substring(0,s.length()-1);
         }
         int numUses = 1;
         if(wordUsage.containsKey(s)) {
            numUses = wordUsage.get(s);
            numUses++;
         }
         wordUsage.put(s, numUses);
      }
      System.out.println(wordUsage);

   }
}
