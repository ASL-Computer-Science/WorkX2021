public class Main {
   public static void main(String[] args) {
      // Write your solution here
   }
}