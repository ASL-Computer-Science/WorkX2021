import java.util.HashMap;
import java.util.Map;

public class Main {
   public static void main(String[] args) {
      HashMap<String, Integer> studentScores = new HashMap<>();
      studentScores.put("Joseph",84);
      studentScores.put("Mary",87);
      studentScores.put("Alexander",84);
      studentScores.put("Linda",90);
      studentScores.put("Richard",74);
      studentScores.put("Laura",98);
      for(Map.Entry e: studentScores.entrySet()){
         System.out.println(e.getKey());
         System.out.println(e.getValue());
      }
   }
}